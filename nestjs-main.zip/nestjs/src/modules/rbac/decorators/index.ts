export * from './permission.decorator';

export * from './permission.entity';
export * from './role.entity';

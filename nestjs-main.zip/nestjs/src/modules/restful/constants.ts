export const CONTROLLER_DEPENDS = 'controller_depends';

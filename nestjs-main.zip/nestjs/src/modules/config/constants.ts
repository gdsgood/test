export enum EnvironmentType {
    DEVELOPMENT = 'development',
    DEV = 'dev',
    PRODUCTION = 'production',
    PROD = 'prod',
    TEST = 'test',
    PREVIEW = 'preview',
}
